POWER SOLUTIONS AC & DC - ANDROID PROJECT

This is the Android Studio source project, not an APK.
It contains a basic Android WebView app with quotation, invoice and receipt screens, item calculations, print-to-PDF and sharing.

To build in GitHub Actions, upload this ZIP to the repository root, then add the build workflow file separately.
